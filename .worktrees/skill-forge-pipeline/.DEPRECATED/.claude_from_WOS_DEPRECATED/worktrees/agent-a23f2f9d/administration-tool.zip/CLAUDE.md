# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

---

## WorldOfShadows — Web Application

The primary deliverable in this repo is **WorldOfShadows**: a two-process Flask application.

| Process | Folder | Purpose | Default port |
|---|---|---|---|
| **Backend** | `Backend/` | REST API, auth (session + JWT), dashboard, DB (SQLite/SQLAlchemy) | 5000 |
| **Administration tool** | `administration-tool/` | Public site, news, wiki, forum pages; management UI (`/manage/*`); no DB | 5001 |

The administration tool calls the Backend API from the **browser** (not server-side). `BACKEND_API_URL` must be the URL the browser can reach.

### Commands

```bash
# --- Backend ---
cd Backend

# Install dependencies
pip install -r requirements.txt

# Local dev (secrets not required with DEV_SECRETS_OK)
DEV_SECRETS_OK=1 flask run --port 5000        # or: python run.py

# Init DB + seed roles/areas on first run
DEV_SECRETS_OK=1 flask init-db

# Create initial SuperAdmin
DEV_SECRETS_OK=1 flask seed-dev-user --username admin --superadmin

# Run tests (must be run from Backend/)
cd Backend && pytest                            # all tests, enforces 85% coverage
pytest tests/test_api.py                       # single file
pytest tests/test_api.py::test_login_success   # single test
pytest --no-cov                                # skip coverage check

# DB migrations (after model changes)
flask db migrate -m "description"
flask db upgrade

# --- Administration tool ---
cd administration-tool

pip install -r requirements.txt
BACKEND_API_URL=http://127.0.0.1:5000 DEV_SECRETS_OK=1 python frontend_app.py

# --- Docker (both together) ---
docker compose up --build    # Backend :8000, administration-tool :5001
```

### Architecture

**Request flow:**
```
Browser → administration-tool (Flask, Jinja2 render)
        → Backend REST API (/api/v1/...) via JS fetch in browser
Backend → SQLite DB (Backend/instance/wos.db)
```

**Backend internal layout:**
- `app/api/v1/` — all REST endpoints (one file per resource: `auth_routes`, `news_routes`, `wiki_routes`, `forum_routes`, etc.)
- `app/models/` — SQLAlchemy models (`User`, `Role`, `Area`, `NewsArticle`, `WikiPage`, `Forum*`, `Slogan`, `SiteSetting`, etc.)
- `app/services/` — business logic layer (called by routes, not DB-directly)
- `app/auth/permissions.py` — JWT permission helpers (`@jwt_required` decorators, `current_user_is_admin()`, etc.)
- `app/auth/feature_registry.py` — stable `manage.*` / `dashboard.*` feature identifiers for area-based access control
- `app/web/` — server-rendered dashboard/auth pages (session-based, separate from the JWT API)
- `app/extensions.py` — Flask extensions init (SQLAlchemy, JWTManager, Limiter, CORS, Migrate, Mail)
- `app/config.py` — `Config` (prod), `DevelopmentConfig` (DEV_SECRETS_OK), `TestingConfig` (in-memory DB, no CSRF)

**Auth model:**
- **Web routes** (`/dashboard`, `/login`, etc.) use Flask session cookies
- **API routes** (`/api/v1/...`) use JWT Bearer tokens
- Users have a `Role` (user / moderator / admin / qa) and a numeric `role_level` (0–100+)
- `role_level >= 100` = SuperAdmin (can modify other admins)
- `is_banned` blocks all role privileges
- Area-based access: users can be scoped to `Area` objects; features gated via `FeatureArea` mapping

**Administration tool layout:**
- `frontend_app.py` — Flask app; no DB; injects `BACKEND_API_URL` into templates as `window.__FRONTEND_CONFIG__`
- `templates/manage/` — management pages (news, users, roles, wiki, forum, data export/import, areas)
- `static/manage_*.js` — one JS file per management section; use `apiFetch()` from `main.js`
- `translations/de.json` + `en.json` — UI i18n (loaded server-side, injected into templates)

**Multilingual content:** `de` (default) and `en`. News articles and wiki pages have per-language records. `SUPPORTED_LANGUAGES` and `DEFAULT_LANGUAGE` set in `Config`.

**Key env vars:**

| Variable | Used by | Effect |
|---|---|---|
| `SECRET_KEY` | Both | Required in production |
| `JWT_SECRET_KEY` | Backend | Falls back to `SECRET_KEY` |
| `DEV_SECRETS_OK=1` | Both | Allows dev fallback secrets + seed commands |
| `DATABASE_URI` | Backend | Defaults to `Backend/instance/wos.db` |
| `CORS_ORIGINS` | Backend | Comma-separated allowed origins (required when apps run on different ports) |
| `BACKEND_API_URL` | Administration tool | Browser-reachable backend URL (no trailing slash) |
| `FRONTEND_URL` | Backend | When set, `GET /` and `GET /news` redirect there |
| `MAIL_ENABLED=1` | Backend | Enables real email sending |

### Testing notes

- Tests live in `Backend/tests/`. Run from `Backend/` directory.
- `conftest.py` provides: `app` (in-memory SQLite, roles seeded), `client`, `test_user`, `auth_headers`, `admin_headers`
- `TestingConfig` disables CSRF, uses 1000/min rate limit, no real mail
- Coverage threshold: 85% (set in `pytest.ini`)
- To test a specific route module: `pytest tests/test_forum_api.py -v`

### Adding a new API resource

1. Create `Backend/app/models/<resource>.py` with SQLAlchemy model
2. Add migration: `flask db migrate -m "add <resource>"` → `flask db upgrade`
3. Create `Backend/app/api/v1/<resource>_routes.py`
4. Register in `Backend/app/api/v1/__init__.py`
5. Add feature identifier to `app/auth/feature_registry.py` if management-gated
6. Create `administration-tool/templates/manage/<resource>.html` + `static/manage_<resource>.js`

---

## Clockwork — Meta-Governance Layer

The `.claude/` directory contains Clockwork, an agent orchestration and governance system used to develop this project. **Do not deploy `.claude/` as application code.**

### System Tools

```bash
python3 .claude/tools/test_ollama.py          # test Ollama availability
python3 .claude/tools/boot_check.py           # verify full environment
python3 -m claudeclockwork.cli --skill-id <skill> --inputs '{}'
python3 .claude/tools/skills/skill_runner.py <skill_name>
```

### Clockwork Tests

```bash
python3 -m pytest tests/ -v                   # Clockwork unit tests (root tests/)
python3 -m pytest tests/ --cov=claudeclockwork
```

### Execution Protocol

Read at session start: `CLAUDE.md` → `.claude/SYSTEM.md` → `.project/MEMORY.md` → `.claude/governance/workflow_triggers.md`

**Workflow keywords:** `Task:` (plan), `Review:` (review), `Critics:` (critique), `Implement:` (execute), `Archive:` (BP-005)

**Escalation:** L0 = autonomous (1 file) → L5 = stop and ask user (orchestrator redesign, backend switch). L2+ requires Ollama; if unavailable → FREEZE.

**Governance trinity:** `specialists.md` + `execution_protocol.md` + `.project/MEMORY.md` — update together when integrating a new agent.

**Model routing:** Local models first (S/M/L tiers via Ollama), then Claude (C0–C3). C4/Opus disabled by default. See `.project/MODEL_POLICY.md`.

**File lifecycle:** Dead files must not exist. Run `dead_file_scan` before each phase. See `.claude/governance/file_lifecycle.md`.

**Skill dispatch:** Manifest CLI (`claudeclockwork.cli`) is preferred (109 skills); legacy runner (`.claude/tools/skills/skill_runner.py`) for scripting.
